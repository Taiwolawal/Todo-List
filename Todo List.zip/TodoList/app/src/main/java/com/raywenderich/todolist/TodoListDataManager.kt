package com.raywenderich.todolist

import android.app.Application
import android.preference.PreferenceManager
import androidx.preference.PreferenceManager
import androidx.lifecycle.AndroidViewModel

class TodoListDataManager(app: Application): AndroidViewModel(app) {
    private val context = app.applicationContext

    fun saveList(list: TaskList){
        val sharedPrefs = PreferenceManager.getDefaultSharedPreferences(context).edit()
    }
}
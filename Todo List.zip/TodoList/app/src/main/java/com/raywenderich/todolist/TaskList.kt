package com.raywenderich.todolist

class TaskList(val name: String, val tasks: ArrayList<String> = ArrayList()) {
}